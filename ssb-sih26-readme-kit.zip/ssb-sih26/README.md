<div align="center">

<img src="assets/banner.svg" alt="SeemaDrishti: isometric 3D banner" width="100%"/>

<br/>

![Smart India Hackathon 2026](https://img.shields.io/badge/Smart%20India%20Hackathon-2026-ff9933?style=for-the-badge)
![Status](https://img.shields.io/badge/status-prototype-6366f1?style=for-the-badge)
![Node](https://img.shields.io/badge/node-%E2%89%A522-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)

![Cloudflare Workers](https://img.shields.io/badge/Cloudflare-Workers-F38020?style=flat-square&logo=cloudflare&logoColor=white)
![D1](https://img.shields.io/badge/Cloudflare-D1-F38020?style=flat-square&logo=cloudflare&logoColor=white)
![R2](https://img.shields.io/badge/Cloudflare-R2-F38020?style=flat-square&logo=cloudflare&logoColor=white)
![Drizzle ORM](https://img.shields.io/badge/Drizzle-ORM-C5F74F?style=flat-square&logo=drizzle&logoColor=black)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=flat-square&logo=typescript&logoColor=white)

**A secure officer workspace for SSB screening: capture documents, run rule-based checks, review, refer, and keep a full audit trail.**

[Try the demo](#-try-it-in-60-seconds) · [Architecture](#-architecture) · [Getting started](#-getting-started) · [Security](#-security-and-access-model) · [Limitations](#-known-limitations)

</div>

> [!IMPORTANT]
> **Prototype notice.** SeemaDrishti is a private prototype built for Smart India Hackathon 2026. Officer profiles are self-entered and are **not** SSB credential verification. A real SSB identity provider must be integrated before any operational deployment.

---

## Table of Contents

- [About](#-about)
- [Try it in 60 seconds](#-try-it-in-60-seconds)
- [Features](#-features)
- [How a case flows](#-how-a-case-flows)
- [Architecture](#-architecture)
- [Checks: what works today](#-checks-what-works-today)
- [Security and access model](#-security-and-access-model)
- [Getting started](#-getting-started)
- [Testing](#-testing)
- [Project structure](#-project-structure)
- [Camera troubleshooting](#-camera-troubleshooting)
- [Known limitations](#-known-limitations)

---

## 🔭 About

**Seema** (सीमा) means *border* and **Drishti** (दृष्टि) means *vision*. SeemaDrishti gives a screening officer one place to open a case, attach evidence, run checks on what was entered, record a decision, and hand off to a supervisor.

Its design rule is honesty about what is and isn't verified:

- Checks that are not connected are reported as `not_performed`, never silently skipped.
- Civilian statements and document transcriptions are always marked **unverified**.
- The server **refuses a "passed" decision** while any required check is incomplete or a stored result is stale.

New officer profiles start with **no sample cases**.

## 🚀 Try it in 60 seconds

| | Public demo | Officer workspace |
|---|---|---|
| **Route** | `/` (entry screen) and `/judge` | `/officer` |
| **Authentication** | None. Never calls an auth provider | Platform-authenticated identity |
| **Data** | Three clearly fictional cases, **in memory only** | Cloudflare D1 (records) and R2 (files) |
| **Persistence** | Reload or **Reset demo** restores samples and discards uploads | Persistent and owner-scoped |
| **Backend calls** | None. Runs entirely in the current browser tab | Full API with ownership enforcement |

**Fastest path for judges:** open `/judge`. No login, no setup, no database.

Or start at `/`, where the officer-login mockup has optional **name**, **officer ID** and **checkpoint** fields. **Enter prototype** works with every field blank. These values only customize the current tab and are **not credentials**. **Exit demo** returns to the entry screen, and **Open demo directly** jumps to `/judge`.

## ✨ Features

- **Account-bound officer profiles** with persistent cases
- **Document workflow:** JPEG, PNG, WebP and PDF, up to **12 MB**
- **Camera capture** through the browser camera API, with selectable video devices
- **Live face capture** (capture only, not proof of liveness)
- **Version-preserving recapture:** re-capturing the same document type keeps earlier versions and replaces the active one
- **Entered-field checks** on names, birth dates and passport expiry
- **Officer actions** and **supervisor referral status**
- **Civilian information records**, stored separately from document fields
- **Case history and audit events**
- **Stale-result protection** on pass decisions

## 🔄 How a case flows

```mermaid
flowchart LR
    A([Officer signs in]) --> B[Start case<br/>document or manual civilian entry]
    B --> C[Capture / upload<br/>documents + face photo]
    C --> D[Enter fields<br/>name, birth date, passport expiry]
    D --> E{Rule-based checks}
    E -->|any required check<br/>incomplete or stale| F[Pass refused<br/>by server]
    E -->|all required checks complete| G[Officer decision]
    F --> D
    G --> H[Refer to supervisor<br/>status: pending review]
    G --> I[(Case history + audit events)]
    H --> I
```

## 🧊 Architecture

<div align="center">
<img src="assets/architecture-3d.svg" alt="Exploded isometric 3D view of the architecture: officer UI, Worker API, checks engine, Cloudflare D1 and R2" width="100%"/>
</div>

| Layer | Technology | Where |
|---|---|---|
| **Interface** | Embedded into the Worker output at build time | `dist/workspace.js` |
| **API** | Cloudflare Worker | `server/worker.mjs` |
| **Checks** | Rule engine for currently supported checks | `server/checks.mjs` |
| **Records** | Cloudflare D1, schema and migrations via Drizzle | `db/schema.ts`, `drizzle/` |
| **Files** | Cloudflare R2 (documents and face captures) | bound in `wrangler.jsonc` |

Records are **never** stored in `localStorage`. Old reference-only static files are not exposed by the server.

## ✅ Checks: what works today

| Check | Status |
|---|---|
| File-presence checks | ✅ Implemented |
| Rules on officer-entered names | ✅ Implemented |
| Rules on officer-entered birth dates | ✅ Implemented |
| Rules on officer-entered passport expiry | ✅ Implemented |
| OCR / document text extraction | ⏳ `not_performed` |
| Automated capture-quality assessment | ⏳ `not_performed` |
| Document forensics | ⏳ `not_performed` |
| Face matching | ⏳ `not_performed` |
| Liveness detection | ⏳ `not_performed` |
| External records lookup | ⏳ `not_performed` |

## 🔐 Security and access model

- **Platform identity.** `/officer` uses the hosting platform's authenticated user identity. The app issues an **eight-hour, HttpOnly** officer session bound to it. **Logout** revokes the session, then navigates to platform sign-out.
- **Restricted enrollment.** New officer profiles require an address on the server-only `OFFICER_EMAIL_ALLOWLIST` setting. Existing profiles authenticate normally. Signing in to the hosting platform alone does **not** grant enrollment.
- **Ownership enforced.** File reads and case operations require the owning officer or a server-provisioned supervisor role.
- **No client-side role selector** can grant supervisor access.
- **Public surface is minimal.** The public Site audience exposes only the demo and interface assets. Officer APIs still require an officer session.
- **Local identity is localhost-only.** Never set `LOCAL_DEVELOPMENT=true` on a hosted environment. Hosted deployments rely on platform identity headers.

## 🛠 Getting started

**Requirements:** Node.js **22 or newer** and npm.

### Run the public prototype

```sh
npm ci
npm run build
npm run dev
```

Open <http://localhost:4173>, or go straight to `/judge`. Demo records need no database setup.

### Run the persistent `/officer` workspace locally

1. Apply local D1 migrations:

   ```sh
   npx wrangler d1 migrations apply DB --local
   ```

2. Create an ignored `.dev.vars` file (local preview only). See `.env.example` for the other settings:

   ```
   LOCAL_DEVELOPMENT=true
   ```

   The fallback identity is additionally restricted to localhost hostnames.

3. Start the dev server as above and open `/officer`.

### Generate future schema migrations

```sh
npm run db:generate
```

## 🧪 Testing

```sh
# Field-rule and input checks
npm test

# Integration tests (local server must be running)
node tests/integration.mjs
```

The integration suite covers login, persistence, ownership isolation, upload storage, recapture versioning, stale results, logout, and invalid-pass enforcement. It uses isolated local test accounts and does **not** populate hosted officer records.

## 📁 Project structure

```
.
├── assets/               # README visuals (3D banner, architecture diagram)
├── db/
│   └── schema.ts         # D1 storage schema
├── dist/
│   └── workspace.js      # Interface implementation
├── drizzle/              # Generated migrations
├── scripts/              # Project scripts
├── server/
│   ├── worker.mjs        # API implementation (Cloudflare Worker)
│   └── checks.mjs        # Currently supported checks
├── tests/
│   └── integration.mjs   # End-to-end integration checks
├── .env.example
├── drizzle.config.ts
├── package.json
└── wrangler.jsonc        # Cloudflare Worker configuration
```

## 📷 Camera troubleshooting

Camera access needs **HTTPS**, browser permission, and device permission. The interface tells these failures apart: permission denied, unsupported context, device problems, and device in use.

Built-in recovery:

- Retries unsupported constraints with the default camera
- Stops streams on close and navigation
- Offers an HTML capture / file-picker fallback (`device_camera`), which may return an existing photo

The app **cannot** override a browser or OS camera denial. Re-enable access in your browser or system settings.

## ⚠️ Known limitations

- Officer profile details are self-entered and unverified.
- Uploading a document does **not** extract its text. Civilian statements and transcriptions are entered manually and marked unverified.
- Face-photo capture is **not** proof of liveness.
- Direct scanner drivers are not connected. Import scanner output as a file.
- Supervisor referrals are recorded as *pending review*. No notification service is connected.
- OCR, capture quality, forensics, face matching, liveness and external records checks are not connected (see [Checks](#-checks-what-works-today)).
- The public demo keeps data in memory only and resets on reload.

---

<div align="center">

Built for **Smart India Hackathon 2026** · `ssb-26-rootX`

</div>
